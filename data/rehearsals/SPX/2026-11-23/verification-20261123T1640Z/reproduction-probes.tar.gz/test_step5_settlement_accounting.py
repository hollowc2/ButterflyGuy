import json
from pathlib import Path
from decimal import Decimal
from unittest.mock import AsyncMock,patch
import pytest,yaml
from butterfly_guy.core.config import ExecutionSettings
from butterfly_guy.data.schemas import ButterflyCandidate
from butterfly_guy.position.position_manager import fly_settlement_value
from tests.test_order_manager import make_order_manager
OUT=Path('data/rehearsals/SPX/2026-11-23/verification-20261123T1640Z')
SRC=Path('data/rehearsals/SPX/2026-11-23/capture-20261123T163928Z')
BASE=yaml.safe_load((SRC/'config-on-disk.yaml').read_text())
CANDIDATE=ButterflyCandidate(direction='CALL',wing_width=40,center_strike=7360,lower_strike=7320,upper_strike=7400,cost=3.75,max_profit=36.25,reward_risk=36.25/3.75,lower_be=7323.75,upper_be=7396.25,distance_from_spot=98.63,spot_price=7261.37)

def test_observed_paper_accounting_agrees_with_fee_model_and_risk_ledger():
    trade=json.loads((SRC/'trade.jsonl').read_text());meta=trade['metadata']
    if isinstance(meta,str): meta=json.loads(meta)
    fee=Decimal(str(BASE['execution']['paper_commission_per_contract']))*4/100
    entry_mark=Decimal(str(meta['entry_execution_diagnostics']['observed_mark']))
    exit_mark=Decimal(str(meta['exit_mark_at_signal']))
    expected_entry=round(entry_mark+fee,2);expected_exit=round(exit_mark-fee,2)
    assert Decimal(trade['entry_price'])==expected_entry and Decimal(trade['exit_price'])==expected_exit
    pnl=(expected_exit-expected_entry)*100*int(trade['quantity'])
    risk=json.loads((SRC/'risk_state.jsonl').read_text())
    assert Decimal(risk['realized_pnl'])==pnl
    (OUT/'05-observed-accounting.json').write_text(json.dumps({'trade_id':trade['id'],'quantity':trade['quantity'],'entry_mark':str(entry_mark),'exit_signal_mark':str(exit_mark),'modeled_commission_option_points_per_side':str(fee),'expected_rounded_entry':str(expected_entry),'expected_rounded_exit':str(expected_exit),'risk_pnl_dollars':str(pnl),'explanation':'Paper mark_v1 embeds modeled commissions in fill prices; do not subtract them again. Slippage is diagnostic-only. Two-decimal price rounding affects the final dollar amount.'},indent=2))

def test_intrinsic_settlement_grid_for_the_actual_spx_strikes():
    grid=[]
    for spot,expected in [(7200,0),(7320,0),(7340,20),(7360,40),(7380,20),(7400,0),(7500,0)]:
        value=fly_settlement_value(CANDIDATE,spot)
        assert value==expected
        grid.append({'hypothetical_final_spot':spot,'expected_intrinsic':expected,'actual_intrinsic':value,'pnl_dollars_at_recorded_entry':round((value-3.75)*100,2)})
    (OUT/'05-hypothetical-settlement-grid.json').write_text(json.dumps({'synthetic':True,'official_close_observed':False,'exit_commission_at_cash_settlement':0,'grid':grid},indent=2))

@pytest.mark.asyncio
async def test_paper_per_spread_fee_is_invariant_to_simulated_quantity():
    manager,broker=make_order_manager(ExecutionSettings.model_validate(BASE['execution']),underlying='SPX')
    assert manager.settings.paper_trading
    fills=[]
    with patch.object(manager,'_fetch_live_spread',new=AsyncMock(return_value=None)):
        for quantity in (1,2):
            fill=await manager.execute_exit(CANDIDATE,current_value=3.43,quantity=quantity)
            fills.append({'quantity':quantity,'per_spread_fill':fill['fill_price'],'total_dollars':round(fill['fill_price']*100*quantity,2)})
    broker.place_order.assert_not_awaited()
    (OUT/'05-quantity-fee-scaling.json').write_text(json.dumps({'mode':'isolated paper executions; running bot quantity unchanged','signal_mark':3.43,'fills':fills,'real_broker_submits':0},indent=2))
    assert fills[0]['per_spread_fill']==fills[1]['per_spread_fill'],'Paper per-spread commission changes with quantity, then PnL multiplies by quantity again'
