import datetime as dt
from unittest.mock import AsyncMock,MagicMock
import pytest
from butterfly_guy.data.schemas import TradeRecord
from butterfly_guy.services.notifier import DiscordNotifier
from tests.test_position_service_settlement import _telemetry_service,_pos_state,_monitor_patches

@pytest.mark.asyncio
async def test_failed_exit_alert_is_not_marked_complete():
    service=_telemetry_service(None)
    service.config.execution.paper_trading=True
    service.position_manager.update_position_value.return_value=_pos_state(3.43,3.83,entry=3.75)
    service.state_machine=MagicMock()
    service.state_machine.state.name='LOSS'
    service.state_machine.evaluate.return_value=MagicMock(reason='end_of_day',urgency='immediate')
    service._record_exit_metrics=AsyncMock()
    service._exit_mark_parity_report=AsyncMock(return_value={})
    service._start_post_exit_recording=MagicMock()
    service.trade_queries.close_trade=AsyncMock(return_value=True)
    service.order_manager.execute_exit.return_value={'fill_price':3.38,'fill_time':dt.datetime(2026,11,23,16,7,29,tzinfo=dt.timezone.utc),'paper_fill_model':'mark_v1','execution_diagnostics':{}}
    service.notifier=DiscordNotifier('https://invalid.example/no-network')
    service.notifier._post=AsyncMock(return_value=False)
    trade=TradeRecord(trade_id=100001,trade_date=dt.date(2026,11,23),direction='CALL',entry_price=3.75,quantity=1)
    p=_monitor_patches(trade,AsyncMock())
    with p[0],p[1],p[2],p[3],p[4]:
        await service.monitor_loop(trade,MagicMock())
    service.order_manager.execute_exit.assert_awaited_once()
    service.trade_queries.close_trade.assert_awaited_once()
    service.notifier._post.assert_awaited_once()
    completed=[call for call in service.trade_queries.merge_metadata.await_args_list if call.args==(100001,{'exit_secondary_work_pending':False})]
    assert not completed,'Confirmed gap: rejected Discord exit alert was marked complete without retry'
