import json,os,socket,sys
from pathlib import Path
import pytest
blocked=[]
def deny(*args,**kwargs):
    blocked.append('network_connection_blocked')
    raise OSError('Paper verification forbids all real network connections')
socket.socket.connect=deny
socket.socket.connect_ex=deny
socket.create_connection=deny
sys.path.insert(0,str(Path.cwd()))
result=pytest.main(sys.argv[2:])
Path(sys.argv[1]).write_text(json.dumps({'real_network_enabled':False,'blocked_network_attempts':len(blocked),'pytest_exit_code':result},indent=2)+'\n')
sys.exit(result)
