import asyncio,datetime as dt,json
from pathlib import Path
from unittest.mock import AsyncMock,MagicMock,patch
import pytest,yaml
from butterfly_guy.core.config import ProfitManagementSettings
from butterfly_guy.core.metrics import readiness_snapshot,set_readiness
from butterfly_guy.data.schemas import ButterflyCandidate,OptionQuote,TradeRecord
from butterfly_guy.position.position_manager import PositionManager
from tests.test_position_monitoring import _service
OUT=Path('data/rehearsals/SPX/2026-11-23/verification-20261123T1640Z')
SRC=Path('data/rehearsals/SPX/2026-11-23/capture-20261123T163928Z')
DAY=dt.date(2026,11,23)
rows=[json.loads(x) for x in (SRC/'monitoring_leg_quotes.jsonl').read_text().splitlines()][:3]
COMPLETE={float(r['strike']):OptionQuote(symbol=r['symbol'],underlying='SPX',expiration=DAY,strike=float(r['strike']),option_type='CALL',bid=float(r['bid']),ask=float(r['ask']),mark=float(r['mark'])) for r in rows}
CANDIDATE=ButterflyCandidate(direction='CALL',wing_width=40,center_strike=7360,lower_strike=7320,upper_strike=7400,cost=3.75,max_profit=36.25,reward_risk=36.25/3.75,lower_be=7323.75,upper_be=7396.25,distance_from_spot=98.63,spot_price=7261.37)
@pytest.mark.asyncio
@pytest.mark.parametrize('missing_strike',[7320.0,7360.0,7400.0])
async def test_spx_observed_held_leg_missing_then_recovers_without_trading(missing_strike):
    set_readiness(None)
    incomplete={s:q for s,q in COMPLETE.items() if s!=missing_strike}
    observations=[COMPLETE,incomplete,incomplete,incomplete,incomplete,COMPLETE]
    service=_service(observations)
    service.config.strategy.underlying='SPX'
    service.config.execution.paper_trading=True
    settings=ProfitManagementSettings.model_validate(yaml.safe_load((SRC/'config-on-disk.yaml').read_text())['profit_management'])
    service.position_manager=PositionManager('SPX',settings)
    service.state_machine.evaluate.side_effect=None
    service.state_machine.evaluate.return_value=None
    calls=0;readiness=[]
    async def chain(*args,**kwargs):
        nonlocal calls
        calls+=1;readiness.append({'poll':calls,'readiness':readiness_snapshot()})
        if calls==7: raise asyncio.CancelledError
        return {'underlyingPrice':float(rows[0]['spot_price'])}
    service.market_data.get_option_chain.side_effect=chain
    trade=TradeRecord(trade_id=100001,trade_date=DAY,direction='CALL',entry_price=3.75,lower_symbol=COMPLETE[7320.0].symbol,center_symbol=COMPLETE[7360.0].symbol,upper_symbol=COMPLETE[7400.0].symbol)
    with patch('butterfly_guy.services.position_service.is_market_open',return_value=True),patch('butterfly_guy.services.position_service.session_date',return_value=DAY),patch('butterfly_guy.services.position_service.get_0dte_expiration',return_value=DAY),patch('butterfly_guy.services.position_service.asyncio.sleep',new=AsyncMock()),patch('butterfly_guy.services.position_service.notify_telegram',new=AsyncMock(return_value=True)),pytest.raises(asyncio.CancelledError):
        await service.monitor_loop(trade,CANDIDATE)
    events=[c.args[0] for c in service.decision_queries.log_event.await_args_list]
    assert events.count('position_market_data_unavailable')==1 and events.count('position_market_data_recovered')==1
    assert service.state_machine.evaluate.call_count==2
    service.order_manager.execute_exit.assert_not_awaited()
    assert readiness_snapshot()==(True,None)
    (OUT/f'03-missing-leg-{int(missing_strike)}.json').write_text(json.dumps({'input':'three observed SPX leg quotes; one leg deliberately removed','missing_strike':missing_strike,'readiness':readiness,'events':events,'valid_valuation_polls':service.state_machine.evaluate.call_count,'real_broker_submits':0},indent=2))
    set_readiness(None)
