import datetime as dt,json,os
from pathlib import Path
from collections import defaultdict
from zoneinfo import ZoneInfo
from unittest.mock import AsyncMock,patch
import pytest,yaml
from butterfly_guy.core.config import ExecutionSettings,ProfitManagementSettings
from butterfly_guy.data.schemas import ButterflyCandidate
from butterfly_guy.position.position_manager import PositionState
from butterfly_guy.position.state_machine import ProfitStateMachine
from tests.test_order_manager import make_order_manager,make_candidate
OUT=Path('/tmp/spx-readiness-after')
SRC=Path('data/rehearsals/SPX/2026-11-23/capture-20261123T175437Z')
BASE=yaml.safe_load((SRC/'config-on-disk.yaml').read_text())

def state(mark,peak,when,entry=3.75):
    mins=(when.astimezone(ZoneInfo('America/New_York')).hour*60+when.minute)-(9*60+30)
    regime='morning' if mins<120 else ('late_morning' if mins<240 else 'afternoon')
    return PositionState(entry_price=entry,current_value=mark,peak_value=peak,pnl=mark-entry,drawdown_from_peak=(peak-mark)/peak,time_regime=regime,minutes_to_close=390-mins,minutes_since_open=mins)

def test_replay_actual_captured_marks_through_unchanged_profit_rules():
    sm=ProfitStateMachine(ProfitManagementSettings.model_validate(BASE['profit_management']))
    groups=defaultdict(list)
    for name in ('monitoring_leg_quotes','post_exit_leg_quotes'):
        for line in (SRC/(name+'.jsonl')).read_text().splitlines():
            row=json.loads(line);groups[row['ts']].append(row)
    peak=3.75;trace=[]
    for timestamp,rows in sorted(groups.items()):
        assert len(rows)==3 and len({row['strike'] for row in rows})==3
        mark=float(rows[0]['fly_mark']);peak=max(peak,mark)
        signal=sm.evaluate(state(mark,peak,dt.datetime.fromisoformat(timestamp)))
        trace.append({'source_timestamp':timestamp,'source':'observed Schawb leg quotes','mark':mark,'peak':peak,'signal':signal.reason if signal else None})
    (OUT/'02-observed-market-replay.json').write_text(json.dumps({'synthetic':False,'settings':'unchanged normal profit management; forced timed exit removed','points':len(trace),'signals':sum(x['signal'] is not None for x in trace),'trace':trace},indent=2))
    assert trace

@pytest.mark.asyncio
async def test_induced_profit_drawdown_reaches_paper_fill_without_broker_write():
    sm=ProfitStateMachine(ProfitManagementSettings.model_validate(BASE['profit_management']))
    peak=3.75;trace=[];signal=None
    when=dt.datetime(2026,11,23,16,0,tzinfo=dt.timezone.utc)
    for mark in [3.75,7.5,12.0,4.5]:
        peak=max(peak,mark);signal=sm.evaluate(state(mark,peak,when))
        trace.append({'synthetic_mark':mark,'synthetic_peak':peak,'signal':signal.reason if signal else None})
    assert signal and signal.reason=='drawdown_morning'
    settings=ExecutionSettings.model_validate(BASE['execution'])
    assert settings.paper_trading
    manager,broker=make_order_manager(settings,underlying='SPX')
    candidate=ButterflyCandidate(direction="CALL",wing_width=40,center_strike=7360,lower_strike=7320,upper_strike=7400,cost=3.75,max_profit=36.25,reward_risk=36.25/3.75,lower_be=7323.75,upper_be=7396.25,distance_from_spot=98.63,spot_price=7261.37)
    with patch.object(manager,'_fetch_live_spread',new=AsyncMock(return_value=None)):
        fill=await manager.execute_exit(candidate,current_value=4.5,quantity=1,exit_reason=signal.reason,trade_id=100001)
    broker.place_order.assert_not_awaited()
    assert fill['order_id']=='PAPER' and fill['paper_fill_model']=='mark_v1'
    assert fill['fill_price']==round(4.5-4*settings.paper_commission_per_contract/100,2)
    (OUT/'02-induced-profit-exit.json').write_text(json.dumps({'synthetic':True,'purpose':'Force trailing-profit exit branch with fabricated marks; not observed price movement','trace':trace,'fill':fill,'real_broker_submits':broker.place_order.await_count},default=str,indent=2))
