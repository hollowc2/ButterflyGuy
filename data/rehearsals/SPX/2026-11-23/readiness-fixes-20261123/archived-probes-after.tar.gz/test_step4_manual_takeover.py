import json
from pathlib import Path
import pytest
from butterfly_guy.execution.order_manager import OperatorExitTakeoverError
from tests.test_spx_live_test import live_service,run_live_monitor,manual_close_order,_persisted_metadata,_restarted_trade,assert_manual_close_recorded,HELD,FLAT
OUT=Path('/tmp/spx-readiness-after')
@pytest.mark.asyncio
@pytest.mark.parametrize('trigger',['operator_order','ladder_takeover'])
async def test_isolated_takeover_survives_restart_then_adopts_simulated_manual_close(trigger):
    if trigger=='operator_order':
        first=live_service([HELD]*10,[[manual_close_order('WORKING')]]*10)
    else:
        first=live_service([HELD]*10,[[]]*10,execute_exit=OperatorExitTakeoverError('simulated operator canceled bot order'))
    await run_live_monitor(first,polls=2)
    saved=_persisted_metadata(first)
    trade=_restarted_trade(saved)
    assert trade.operator_exit
    second=live_service([HELD]*10,[[manual_close_order('CANCELED')]]*10)
    await run_live_monitor(second,polls=6,trade=trade)
    second.order_manager.execute_exit.assert_not_awaited()
    third=live_service([HELD,FLAT],[[],[manual_close_order()]])
    await run_live_monitor(third,trade=trade)
    third.order_manager.execute_exit.assert_not_awaited()
    assert_manual_close_recorded(third)
    phases=[]
    for name,service in [('takeover',first),('restart_after_cancel',second),('manual_fill_adopted',third)]:
        phases.append({'phase':name,'events':[c.args[0] for c in service.decision_queries.log_event.await_args_list],'simulated_exit_attempts':service.order_manager.execute_exit.await_count,'simulated_close_trade_calls':service.trade_queries.close_trade.await_count})
    (OUT/f'04-{trigger}.json').write_text(json.dumps({'mode':'isolated broker/account fixtures; no network and no real orders','trigger':trigger,'persisted_operator_exit':saved['operator_exit'],'phases':phases},default=str,indent=2))
